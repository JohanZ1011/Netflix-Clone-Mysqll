import React, { useState } from 'react';
import { AgregarUse } from '../../services/peliculas';

function Agregar(props) {
	
    const { closeModal } = props;

    const [form, setForm] = useState({
		Nombre: '',
		imagen: '',
        desscripcion: '',
	});

	
	const changeForm = (field, value) => {
		setForm({ ...form, [field]: value });
	};

	const submit = async (event) => {
		event.preventDefault();
		await AgregarUse(form);
        return
		// closeModal(true);
	};
    
	return (
		<div className='container pt-4'>
			<div className='row'>
				<div className='colg-lg-6'>
					<div className='card text-center'>
						<div className='card-body'>
							<h3>Agregar Una Pelicula</h3>

							<span className='badge badge-danger text-danger'>
								TODOS LOS CAMPOS SON OBLIGATORIOS
							</span>
							
							<form className='mt-4' onSubmit={submit}>
								
                                <div className='row'>
									
                                    <div className='col'>

										<input
											type='text'
											className='form-control form-control-lg'
											placeholder='Nombre'
											value={ form.Nombre}
											
											onChange={(event) => {
												changeForm(
													'Nombre',
													event.target.value
												);
											}}
										/>
											<input
											type='text'
											className='form-control form-control-lg'
											placeholder='Imagen url'
											value={ form.imagen}
											
											onChange={(event) => {
												changeForm(
													'imagen',
													event.target.value
												);
											}}
										/>
                                        <input
											type='text'
											className='form-control form-control-lg'
											placeholder='desscripcion'
											value={ form.desscripcion}
											
											onChange={(event) => {
												changeForm(
													'desscripcion',
													event.target.value
												);
											}}
										/>
									</div>
									<div className='col'>
									</div>
								</div>
								<div className='mt-3'>
									
									<button
										type='submit'
										className='btn btn-primary btn-lg mt-2'> 
										Agregar
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

export default Agregar;