import React, { useEffect } from 'react';
import './App.css';
import HomeScreen from './screens/HomeScreen'
import LoginScreen from './screens/LoginScreen'
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { auth } from './firebase';
import ProfileScreen from './screens/ProfileScreen'
import { useDispatch, useSelector } from 'react-redux'
import Videos from './videos/Videos'
import Agregar from './videos/Botones/Agregar'
import { login, logout, selectUser } from './features/userSlice';


function App() {

  const user = useSelector(selectUser);

  const dispatch = useDispatch();

  useEffect(() => {
    const unsubcribe = auth.onAuthStateChanged(userAuth => {
      if (userAuth) {
        console.log(userAuth);
        dispatch(
          login({

            uid: userAuth.uid,
            email: userAuth.email,
          })
        );
      } else {

        dispatch(logout());
      }

    });
    return unsubcribe;
  }, [dispatch]);


  return (
    <div className="app">
      <Router>
        {!user ? (
          <LoginScreen />
        ) : (
          <Switch>
            <Route path="/profile">
              <ProfileScreen />
            </Route>
            <Route exact path="/">
              <HomeScreen />
            </Route>
            <Route path="/videos">
              <Videos />
            </Route>
            <Route path="/agregar">
              <Agregar />
            </Route>
          </Switch>
        )}
      </Router>

    </div>
  );
}

export default App;
