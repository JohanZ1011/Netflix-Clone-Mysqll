import axios from 'axios'

export async function getPeliculas(){
    try{
       const response = await axios({
           url: `http://localhost:8000/peliculas`,
           method: 'get'
       })     
       return response;
    }catch(e){
        console.log(e);
    }
}

export async function AgregarUse(form){
    try{
       const response = await axios({
           url: `http://localhost:8000/peliculas/agregar`,
           method: 'post' , 
           data:form,
       })     
       return response;
    }catch(e){
        console.log(e);
    }
}
export async function ModificarUse(form){
    try{
       const response = await axios({
           url: `http://localhost:8000/peliculas/modificar/${form.id_pelicula}`,
           method: 'put' , 
           data:form,
       })     
       return response;
    }catch(e){
        console.log(e);
    }
}
export async function EliminarUse(id_pelicula){
   
    try{

       const response = await axios({

           url: `http://localhost:8000/peliculas/Eliminar/${id_pelicula}`,
           method: 'delete' ,          
       })     
       return response;
    }catch(e){
        console.log(e);
    }
}