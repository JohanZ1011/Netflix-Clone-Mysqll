import firebase from 'firebase'

const firebaseConfig = {
    apiKey: "AIzaSyC9YWDTznSbWMsxY2upMidxCVH4MyoAuHk",
    authDomain: "netflix-700b7.firebaseapp.com",
    projectId: "netflix-700b7",
    storageBucket: "netflix-700b7.appspot.com",
    messagingSenderId: "507464999802",
    appId: "1:507464999802:web:500b1e27a89d1a36b16cc3"
  };
  
const firebaseApp = firebase.initializeApp(firebaseConfig);
const fb = firebaseApp.firestore();
const auth = firebase.auth();

export { auth };
export default fb;