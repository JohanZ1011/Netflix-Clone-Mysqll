/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : ejercicio

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-06-05 08:13:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for peliculas
-- ----------------------------
DROP TABLE IF EXISTS `peliculas`;
CREATE TABLE `peliculas` (
  `id_peliculas` int(55) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `desscripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_peliculas`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of peliculas
-- ----------------------------
INSERT INTO `peliculas` VALUES ('1', 'Avengers', 'https://i.pinimg.com/originals/3e/6e/6f/3e6e6fb82ed3f03eacedc6a49d757a30.jpg', 'Cuando un enemigo inesperado amenaza la seguridad del planeta y de sus habitantes, Nick Fury (Samuel L. Jackson), director de SHIELD, monta un dispositivo con todos los hombres capaces de preservar a la humanidad del caos.');
INSERT INTO `peliculas` VALUES ('2', 'Avengers', 'https://i.pinimg.com/originals/3e/6e/6f/3e6e6fb82ed3f03eacedc6a49d757a30.jpg', 'Cuando un enemigo inesperado amenaza la seguridad del planeta y de sus habitantes, Nick Fury (Samuel L. Jackson), director de SHIELD, monta un dispositivo con todos los hombres capaces de preservar a la humanidad del caos.');
INSERT INTO `peliculas` VALUES ('3', 'dragon ball z', 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTL3oQJMXHBklldU-IkzZQ1y8XzMwveNL_fTB7H3daZqOx9LEN0', 'Un valiente joven con poderes increíbles se aventura hacia un viaje místico en tierras exóticas llenas de guerreros nobles, princesas hermosas, monstruos mutantes, extraterrestres y crueles ejércitos.');
INSERT INTO `peliculas` VALUES ('4', 'harry potter', 'https://eloutput.com/app/uploads-eloutput.com/2021/02/libros-harry-potter-10.jpg', 'Harry Potter');
INSERT INTO `peliculas` VALUES ('6', 'mortal combat', 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQaAU_52egCuqLrxqrRCWtU1KO7_TMgkI0gLJRDRMm-8yZczOOC', 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQaAU_52egCuqLrxqrRCWtU1KO7_TMgkI0gLJRDRMm-8yZczOOC');
INSERT INTO `peliculas` VALUES ('7', 'Pablo Escobar', 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Pablo_Escobar_Mug.jpg/230px-Pablo_Escobar_Mug.jpg', 'Pablo Emilio Escobar Gaviria fue un narcotraficante, terrorista y político colombiano, fundador y máximo líder del Cartel de Medellín.​​');
