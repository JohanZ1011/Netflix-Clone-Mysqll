const database = require('../models/peliculas');

async function listAll(req,res) {
    const administrador = await database().listAll();
    res.status(200).json({administrador})
}


async function AgregarVa(req,res){
    const data = req.body;
    await database().AgregarVa(data);
    res.status(200).json({
        success: 1,
        msj:"agregado con exito"
    }
    )
}

async function EliminarVa(req,res){
    const data = req.params.id;
    await database().EliminarVa(data)
    res.status(200).json({
        success: 1,
        msj:"user eliminada"
    }
    )
}

async function ModificarVa(req,res){
    const data =[ 
        req.body.producto,
        req.body.precio,
        req.params.id
    ]
    await database().ModificarVa(data);
    res.status(200).json({
        success: 1,
        msj:"Lo modifico con exito"
    }
    )
}


module.exports =
 {
    listAll,
    AgregarVa,
    EliminarVa,
    ModificarVa,
}

