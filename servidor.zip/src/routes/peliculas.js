const express = require('express');
const routes = express.Router();
const PeliculasControllers = require('../controllers/PeliculasControllers');

// CONSULTAR TODOS LOS USUARIOS
routes.get('/', PeliculasControllers.listAll);
// AGREGAR PELICULA
routes.post('/agregar', PeliculasControllers.AgregarVa);
// ELIMINAR USUARIO
routes.delete('/Eliminar/:id', PeliculasControllers.EliminarVa);
// MODIFICAR USUARIO
routes.put('/Modificar/:id', PeliculasControllers.ModificarVa);

module.exports = routes;