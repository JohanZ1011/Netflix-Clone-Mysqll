'use strict'
const pool =  require('../database')

module.exports = function() {
////////////////////////BUZOS///////////////////

async function listAll(datos) {
    let administrador =`SELECT * from peliculas`;
    return await pool.query(administrador,datos)
}

async function AgregarVa(datos) {
    await pool.query(`insert into peliculas set ?`, [datos]);
}

async function EliminarVa(datos) {
    let sql = `DELETE from peliculas where id_peliculas = ?`;
    return await pool.query(sql,datos)
}

async function ModificarVa(datos){ 
   let sql = ` UPDATE peliculas
   set  peliculas=? 
   where id_peliculas=?`;
   return await pool.query(sql,datos)
}

   return {
        listAll,
        AgregarVa,
        EliminarVa,
        ModificarVa,
   }
}
